/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "autoencoder.h"
#include "autoencoder_data.h"
#include "ai_platform.h"
#include "ai_datatypes_defines.h"
#include <stdio.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define CURRENT_MEAN      2.0017f
#define CURRENT_STD       0.1478f

#define VIBRATION_MEAN    0.2011f
#define VIBRATION_STD     0.0296f

#define THRESHOLD 0.045f
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
UART_HandleTypeDef huart4;

/* USER CODE BEGIN PV */
//CRC_HandleTypeDef hcrc;
float error;
/* AI Buffers */

/* AI Variables */
static ai_handle autoencoder = AI_HANDLE_NULL;

AI_ALIGNED(32)
static ai_u8 activations[AI_AUTOENCODER_DATA_ACTIVATIONS_SIZE];
AI_ALIGNED(32)
static ai_float input_data[AI_AUTOENCODER_IN_1_SIZE];
AI_ALIGNED(32)
static ai_float output_data[AI_AUTOENCODER_OUT_1_SIZE];



static ai_buffer *ai_input;
static ai_buffer *ai_output;

static ai_network_report report;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART4_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */



int _write(int file, char *ptr, int len)
{
   HAL_UART_Transmit(&huart4, (uint8_t *)ptr, len, HAL_MAX_DELAY);
   return len;
}





void AI_Init(void)
{
    ai_error err;

    const ai_handle acts[] =
    {
        activations
    };

    err = ai_autoencoder_create_and_init(
            &autoencoder,
            acts,
            NULL);

    if(err.type != AI_ERROR_NONE)
    {
        printf("AI Initialization Failed\r\n");

        Error_Handler();
    }

    ai_autoencoder_get_report(
    		autoencoder,
            &report);

    ai_input =
        ai_autoencoder_inputs_get(
            autoencoder,
            NULL);

    ai_output =
        ai_autoencoder_outputs_get(
            autoencoder,
            NULL);

    printf("Autoencoder Initialized Successfully\r\n");
}

uint8_t AI_RunInference(float current,
                        float vibration)
{
	float current_norm =(current - 2.01f) / 0.15f;
	float vibration_norm =(vibration - 0.20f) / 0.03f;

    input_data[0] = current_norm;
    input_data[1] = vibration_norm;

    ai_input[0].data = AI_HANDLE_PTR(input_data);

    ai_output[0].data = AI_HANDLE_PTR(output_data);

    if(ai_autoencoder_run(
            autoencoder,
            ai_input,
            ai_output) != 1)
    {
        printf("Inference Failed\r\n");

        return 0;
    }

    float current_recon = output_data[0];
    float vibration_recon = output_data[1];

    error = (
    (current_norm-current_recon)*
    (current_norm-current_recon)
    +
    (vibration_norm-vibration_recon)*
    (vibration_norm-vibration_recon)
    )/2.0f;

    if(error > THRESHOLD)
    {
        printf("ANOMALY\r\n");
        return 1;
    }
    else
    {
        printf("NORMAL\r\n");
        return 0;
    }

}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_UART4_Init();
  /* USER CODE BEGIN 2 */
  AI_Init();

//  float current;
//  float vibration;
//
//
//
//  uint8_t anomaly;
//
//  current = 2.05f;
//  vibration = 0.20f;;

  typedef struct
  {
      float current;
      float vibration;
  } SensorData;
  SensorData testData[] =
  {
      {2.0f, 0.20f},   // Normal
      {2.1f, 0.18f},   // Normal
      {5.5f, 1.80f},   // Anomaly
      {5.8f, 2.10f},   // Anomaly
  };

  float current;
  float vibration;

 while(1)
 {


	 for(int i=0;i<4;i++)
	 {
		 current=testData[i].current;
		 vibration=testData[i].vibration;
		 uint8_t anomaly =AI_RunInference(current,vibration);

		   printf("\r\n==============================\r\n");

		   printf("Current      : %.2f A\r\n",
		           current);

		   printf("Vibration    : %.2f g\r\n",
		           vibration);

		   printf("Normalized Current : %.5f\r\n",
		           input_data[0]);

		   printf("Normalized Vibration : %.5f\r\n",
		           input_data[1]);

		   printf("Reconstructed Current : %.5f\r\n",
		           output_data[0]);

		   printf("Reconstructed Vibration : %.5f\r\n",
		           output_data[1]);

		   printf("Error : %.5f\r\n",error);

		   printf("Threshold : %.5f\r\n",
		           THRESHOLD);

		   if(anomaly)
		   {
		       printf("STATUS : ANOMALY\r\n");

		       HAL_GPIO_WritePin(
		               GPIOD,
		               GPIO_PIN_12,
		               GPIO_PIN_SET);
		   }
		   else
		   {
		       printf("STATUS : NORMAL\r\n");

		       HAL_GPIO_WritePin(
		               GPIOD,
		               GPIO_PIN_12,
		               GPIO_PIN_RESET);
		   }

		   HAL_Delay(1000);
	 }

}
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOD, GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin : PD12 */
  GPIO_InitStruct.Pin = GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
