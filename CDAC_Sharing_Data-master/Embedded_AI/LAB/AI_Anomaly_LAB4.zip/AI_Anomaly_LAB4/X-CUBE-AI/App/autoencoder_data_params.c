/**
  ******************************************************************************
  * @file    autoencoder_data_params.c
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-07-25T11:42:07+0530
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#include "autoencoder_data_params.h"


/**  Activations Section  ****************************************************/
ai_handle g_autoencoder_activations_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(NULL),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};




/**  Weights Section  ********************************************************/
AI_ALIGNED(32)
const ai_u64 s_autoencoder_weights_array_u64[59] = {
  0xbe38ca79bf5a4d0aU, 0xbc9fc8353cdca134U, 0x3ef67cf9bf26004bU, 0xbec3c4903f2b168fU,
  0xbf4acdf3b98bc444U, 0x3f40c9e2be2fa148U, 0xbea781ee3f62829dU, 0xbf1acb1d3dc83787U,
  0xbdc0145a3f2599e1U, 0xbde709633d95b2c4U, 0x3ce261fe3eabc342U, 0x3d816579bdc31b25U,
  0xbed652b33dc98dbaU, 0xbf5232a93f0dbf57U, 0x3e679e6dbd876689U, 0x3e1c294e3ef13b6dU,
  0x3b5619483ef457afU, 0x3f12ba533ef8fc0cU, 0x3e8c1ed23f117e34U, 0xbf56a0debf3967ccU,
  0xbea2e0c83ea0117aU, 0xbd781f633e7684afU, 0xbe5eff3d3f1f7eecU, 0x3ea553e03ce70e69U,
  0xbf1ae18cbe109d58U, 0x3ea483963cde07cfU, 0x3f0e64f4be806559U, 0xbd56367c3eab0c2dU,
  0xbd32e29f3ed0ef07U, 0xbdd29d4b3e722f8cU, 0x3db3f8693d38728fU, 0x3df961fd3f600d73U,
  0x3ebc25adbe5b4d1eU, 0x3f44022ebf04fcb2U, 0xbe18cd91bf8176b1U, 0x3f9dbc0f3e9261fbU,
  0x3ecaba4abeae8c02U, 0x3dd280733ef72995U, 0x3f200db53ee9381eU, 0xbeaa90cc3f1c6edaU,
  0x3e41a4e03f227744U, 0x3f51c428bcb23cbdU, 0xbf051e4d3ecc02d1U, 0xbe82318fbe109225U,
  0x3f42bd3b3e4ec523U, 0x3d939d633e5073deU, 0x3d9a6c9bbe06f773U, 0x3e881e233ebab6fbU,
  0x3e0ce4dcbe708738U, 0xbe86b050be56a436U, 0x3f3e8266bdd066c4U, 0x3e70d7e73f71033fU,
  0x3dcb94debf0e367aU, 0xbf32259bbed92194U, 0x3f170140bf325e55U, 0xbf848d5bbeca316aU,
  0x3f7929713d44dd2bU, 0x3e6f31eb3ddd2476U, 0x3ea3e6ac3ee732b4U,
};


ai_handle g_autoencoder_weights_table[1 + 2] = {
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
  AI_HANDLE_PTR(s_autoencoder_weights_array_u64),
  AI_HANDLE_PTR(AI_MAGIC_MARKER),
};

