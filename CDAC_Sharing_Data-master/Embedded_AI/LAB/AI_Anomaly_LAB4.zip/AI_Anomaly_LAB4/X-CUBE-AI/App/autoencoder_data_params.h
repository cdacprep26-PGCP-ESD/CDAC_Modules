/**
  ******************************************************************************
  * @file    autoencoder_data_params.h
  * @author  AST Embedded Analytics Research Platform
  * @date    2026-07-25T11:42:07+0530
  * @brief   AI Tool Automatic Code Generator for Embedded NN computing
  ******************************************************************************
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  ******************************************************************************
  */

#ifndef AUTOENCODER_DATA_PARAMS_H
#define AUTOENCODER_DATA_PARAMS_H

#include "ai_platform.h"

/*
#define AI_AUTOENCODER_DATA_WEIGHTS_PARAMS \
  (AI_HANDLE_PTR(&ai_autoencoder_data_weights_params[1]))
*/

#define AI_AUTOENCODER_DATA_CONFIG               (NULL)


#define AI_AUTOENCODER_DATA_ACTIVATIONS_SIZES \
  { 48, }
#define AI_AUTOENCODER_DATA_ACTIVATIONS_SIZE     (48)
#define AI_AUTOENCODER_DATA_ACTIVATIONS_COUNT    (1)
#define AI_AUTOENCODER_DATA_ACTIVATION_1_SIZE    (48)



#define AI_AUTOENCODER_DATA_WEIGHTS_SIZES \
  { 472, }
#define AI_AUTOENCODER_DATA_WEIGHTS_SIZE         (472)
#define AI_AUTOENCODER_DATA_WEIGHTS_COUNT        (1)
#define AI_AUTOENCODER_DATA_WEIGHT_1_SIZE        (472)



#define AI_AUTOENCODER_DATA_ACTIVATIONS_TABLE_GET() \
  (&g_autoencoder_activations_table[1])

extern ai_handle g_autoencoder_activations_table[1 + 2];



#define AI_AUTOENCODER_DATA_WEIGHTS_TABLE_GET() \
  (&g_autoencoder_weights_table[1])

extern ai_handle g_autoencoder_weights_table[1 + 2];


#endif    /* AUTOENCODER_DATA_PARAMS_H */
